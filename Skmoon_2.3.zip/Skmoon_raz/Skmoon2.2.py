import random
import colorsys
import colored
import colorama
import banner
import webbrowser
from pystyle import Colorate, Colors
import os
import pystyle
import subprocess
import socket
import pyfiglet
import randmac
import username
import asyncio
import threading
import random
from pystyle import Colors, Box, Write, Center, Colorate, Anime
import time
import requests
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import whois
import os
import string
from faker import Faker
import socket
import phonenumbers
import platform
import phonenumbers
import requests
import os
from pystyle import Colorate, Colors

COLOR_CODE = {
        "GREEN": "\033[32m",
        "BOLD": "\033[01m",
        "RESET": "\033[0m",
    }


#горепастеры, ода

print(Colorate.Horizontal(Colors.red_to_white, (""" 
     .
     
                                                        / ___|| | ___ __ ___ ___ ___ _ __  
                                .                       \___ \| |/ / '_ ` _ \ / _ \ / _ \| '_ \
                                                           ___) | <| | | | | | (_) | (_) | | | |
.                                                  .     |____/|_|\_\_| |_| |_|\___/ \___/|_| |_|█ 
                                                     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ 
                                                     ┃ dev > ??????               |         channel > ????????????????  ┃
                                                     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                                                     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
                                                     ┃                        version > 2.2.                              ┃
                                                     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
          ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
          ┃ [1] > Поиск по никнейму             ┃ [21] > Генератор карт                   ┃ [41] > Генератор компании               ┃ [61] > Сократить ссылку            ┃
          ┃ [2] > Поиск по номеру               ┃ [22] > Бомбер                           ┃ [42] > Генератор QR кода                ┃ [62] > Скачать видео с YouTube     ┃
          ┃ [3] > Поиск по IP                   ┃ [23] > Запуск инструмента Anubis        ┃ [43] > Генератор улицы                  ┃ [63] > Скачать пин из Pinterest    ┃
          ┃ [4] > Поиск по ФИО                  ┃ [24] > Запуск инструмента WannaCry      ┃ [44] > Генератор цвета                  ┃ [64] > Сервисы для Osint           ┃
          ┃ [5] > Поиск по почте                ┃ [25] > Генератор оскорблений            ┃ [45] > ???????????????                    ┃ [65] > Генератор анекдотов         ┃
          ┃ [6] > Поиск по адресу               ┃ [26] > Создать баннер                   ┃ [46] > Генератор Microsoft записи       ┃ [66] > Как скрыть данные в тг ботах┃
          ┃ [7] > Поиск по Telegram id/username ┃ [27] > WebCrawler                       ┃ [47] > Как создавать Telegram ботов     ┃ [67] > Снятие спам блока           ┃
          ┃ [8] > Поиск универсальный           ┃ [28] > Поиск по социальным сетям        ┃ [48] > Как создавать свои софты         ┃ [68] > Soon...                     ┃
          ┃ [9] > Генератор новостей            ┃ [29] > Цензура пользовательского текста ┃ [49] > Генератор комплиментов           ┃ [69] > Soon...                     ┃
          ┃ [10] > Фишинг Telegram              ┃ [30] > Мануалы                          ┃ [50] > Генератор цитат                  ┃ [70] > Soon...                     ┃
          ┃ [11] > Сносер Telegram              ┃ [31] > Гео по номеру                    ┃ [51] > Генератор стихов                 ┃ [71] > Soon...                     ┃
          ┃ [12] > Генератор пароля             ┃ [32] > Информация по сайту              ┃ [52] > Генератор имени для котиков      ┃ [72] > Soon...                     ┃
          ┃ [13] > Генератор ИНН                ┃ [33] > Генератор почт                   ┃ [53] > Генератор телефона               ┃ [73] > Soon...                     ┃
          ┃ [14] > Генератор личности 1         ┃ [34] > Генератор русских номеров        ┃ [54] > Генератор лицензии               ┃ [74] > Soon...                     ┃
          ┃ [15] > DDoS Аттака 1                ┃ [35] > Генератор айпи                   ┃ [55] > Генератор номера авто            ┃ [75] > Soon...                     ┃ 
          ┃ [16] > DDoS Аттака 2                ┃ [36] > Генератор снилса                 ┃ [56] > Генератор шуток                  ┃ [76] > Soon...                     ┃
          ┃ [17] > Генератор личности 2         ┃ [37] > Генератор mac-адресов            ┃ [57] > Генератор автомобилей            ┃ [77] > Soon...                     ┃
          ┃ [18] > Составление DOX              ┃ [38] > Генератор русских адресов        ┃ [58] > Генератор страшной истории       ┃ [78] > porno                      ┃
          ┃ [19] > Порт сканнер                 ┃ [39] > Генератор украинских адресов     ┃ [59] > Генератор акции                  ┃ [79] > ??????                      ┃
          ┃ [20] > Сносер Discord               ┃ [40] > Генератор никнейма               ┃ [60] > Скачать видео с TikTok           ┃ [80] > Информация                  ┃
          ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛         
""").strip()))

bs = input(Colorate.Horizontal(Colors.red_to_white, ("[?] Выберите пункт:").strip()))

if bs == "1":

    user = input(Colorate.Horizontal(Colors.green_to_white, ("Введите ник:").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, ("Проверьте эти ссылки").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ──────────────────────────────────────────────────────────────────────────── ").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" телеграмм: https://t.me/" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" вконтакте: https://vk.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" oдноклассники: https://ok.ru/" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" github: https://github.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" яндекc: https://yandex.ru/search/?text=" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" инстаграм: https://www.instagram.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" тикток: https://www.tiktok.com/@" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" твиттер: https://twitter.com/" + user).strip())) 
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" фейсбук: https://www.facebook.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ютуб: https://www.youtube.com/@" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ─────────────────────────────────────────────────────────────────────────").strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" роблокс: https://www.roblox.com/user.aspx?username=" + user).strip()))
    print(Colorate.Horizontal(Colors.green_to_white, (" ──────────────────────────────────────────────────────────────────────────── ").strip()))
    input("")


elif bs == "2":
    subprocess.run(['python', 'searchnumber.py'])

elif bs == "3":
    subprocess.run(['python', 'searchip.py'])

elif bs == "4":
    subprocess.run(['python', 'searchfio.py'])
    
elif bs == "5":
    subprocess.run(['python', 'searchemail.py'])

elif bs == "6":
    subprocess.run(['python', 'searchadress.py'])

elif bs == "7":
    subprocess.run(['python', 'searchtg.py'])

elif bs == "8":
    subprocess.run(['python', 'searchbase.py'])

elif bs == "9":
    subprocess.run(['python', 'gennews.py'])

elif bs == "10":
    subprocess.run(['python', 'fishingtelegram2.py'])

elif bs == "11":
    subprocess.run(['python', 'snostg.py'])

elif bs == "12":
    subprocess.run(['python', 'genpasswd.py'])

elif bs == "13":
    subprocess.run(['python', 'geninn.py'])

elif bs == "14":
    subprocess.run(['python', 'genfake.py'])

elif bs == "15":
    subprocess.run(['python', 'DDoS1.py'])

elif bs == "16":
    subprocess.run(['python', 'DDoS.py'])

elif bs == "17":
    subprocess.run(['python', 'fakeinfo.py'])

elif bs == "18":
    subprocess.run(['python', 'doxtemp.py'])

elif bs == "19":
    subprocess.run(['python', 'portscanner.py'])

elif bs == "20":
    subprocess.run(['python', 'snosdisc.py'])

elif bs == "21":
    subprocess.run(['python', 'gencards.py'])

elif bs == "22":
    subprocess.run(['python', 'bomber.py'])

elif bs == "23":
    subprocess.run(['python', 'anubis.py'])

elif bs == "24":
    subprocess.run(['python', 'wannacry.py'])

elif bs == "25":
    subprocess.run(['python', 'gentroll.py'])

elif bs == "26":
    subprocess.run(['python', 'gentext.py'])

elif bs == "27":
    subprocess.run(['python', 'webcrawler.py'])

elif bs == "28":
    subprocess.run(['python', 'searchsocial.py'])

elif bs == "29":
    subprocess.run(['python', 'swat.py'])

elif bs == "30":
    subprocess.run(['python', 'manuals.py'])

elif bs == "31":
    subprocess.run(['python', 'geonumber.py'])

elif bs == "32":
    subprocess.run(['python', 'portscanner.py'])

elif bs == "33":
    subprocess.run(['python', 'genmail.py']) 

elif bs == "34":
    subprocess.run(['python', 'genruss.py']) 

elif bs == "35":
    subprocess.run(['python', 'genip.py']) 

elif bs == "36":
    subprocess.run(['python', 'gensnils.py']) 

elif bs == "37":
    subprocess.run(['python', 'genmac.py']) 

elif bs == "38":
    subprocess.run(['python', 'genadrs.py']) 
    
elif bs == "39":
    subprocess.run(['python', 'genadrs1.py']) 

elif bs == "40":
    subprocess.run(['python', 'gennick.py']) 

elif bs == "41":
    subprocess.run(['python', 'gencomp.py']) 

elif bs == "42":
    subprocess.run(['python', 'genqr.py']) 

elif bs == "43":
    subprocess.run(['python', 'genstreet.py']) 

elif bs == "44":
    subprocess.run(['python', 'gencol.py']) 

elif bs == "45":
    subprocess.run(['python', 'genssh.py']) 

elif bs == "46":
    subprocess.run(['python', 'genmicr.py']) 

elif bs == "47":
  print(Colorate.Horizontal(Colors.green_to_white, ("""
Создание собственного Telegram-бота на Python может быть увлекательным и полезным опытом! В этом руководстве я расскажу вам, как написать своего бота, используя библиотеку python-telegram-bot.

### Шаг 1: Подготовка

#### 1.1 Установка необходимых инструментов

Убедитесь, что у вас установлен Python. Вы можете загрузить его с [официального сайта Python](https://www.python.org/downloads/).

После установки Python, установите библиотеку python-telegram-bot с помощью pip:

pip install python-telegram-bot

#### 1.2 Создание бота в Telegram

1. Откройте Telegram и найдите пользователя @BotFather.
2. Напишите ему команду /newbot и следуйте инструкциям. Вы получите токен, который будет нужен для работы вашего бота.
3. Запишите токен, он будет выглядеть вроде 123456789:ABCdefGhiJklMNOpqRstUvwxYz.

### Шаг 2: Создание простого бота

Создайте новый файл, например, my_telegram_bot.py, и напишите следующий код:






import logging
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# Включение логирования
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Определение команды /start
def start(update: Update, context: CallbackContext) -> None:
    update.message.reply_text('Привет! Я ваш бот. Как я могу помочь?')

# Определение команды /help
def help_command(update: Update, context: CallbackContext) -> None:
    update.message.reply_text('Вы можете использовать следующие команды:\n/start - начать разговор\n/help - получить справку')

# Обработка текстовых сообщений
def echo(update: Update, context: CallbackContext) -> None:
    update.message.reply_text(update.message.text)

# Ошибка логирования
def error(update: Update, context: CallbackContext) -> None:
    logger.warning(f'Обновление "{update}" вызвало ошибку "{context.error}"')

# Основная функция
def main() -> None:
    # Вставьте ваш токен здесь
    TOKEN = 'YOUR TELEGRAM BOT TOKEN HERE'
    
    # Создание Updater и диспетчера
    updater = Updater(TOKEN)
    
    # Получение диспетчера для регистрации обработчиков
    dispatcher = updater.dispatcher
    
    # Определение обработчиков команд
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("help", help_command))
    
    # Обработка обычных сообщений
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, echo))
    
    # Логирование ошибок
    dispatcher.add_error_handler(error)
    
    # Запуск бота
    updater.start_polling()
    
    # Ожидание завершения работы
    updater.idle()

if __name__ == '__main__':
    main()










### Шаг 3: Запуск бота

1. Замените строку YOUR TELEGRAM BOT TOKEN HERE на токен, который вы получили от BotFather.
2. Запустите ваш бот:

python my_telegram_bot.py

### Шаг 4: Взаимодействие с ботом

- Найдите вашего бота в Telegram (по имени, которое вы ему дали).
- Напишите команду /start и посмотрите, как ваш бот ответит.
- Попробуйте отправить текстовое сообщение - ваш бот выполнит эхо-ответ с тем же текстом.

### Шаг 5: Дальнейшее развитие

Вот несколько идей для улучшения вашего бота:

1. Добавление дополнительных команд: Вы можете добавить больше команд, например, /weather для получения прогноза погоды, интегрируя API с погодой.

2. Создание кнопок и меню: Вы можете использовать встроенные клавиатуры Telegram, чтобы создать более интерактивный опыт.

3. Хранение данных: Рассмотрите возможность использования базы данных (например, SQLite или PostgreSQL) для хранения информации о пользователях и их запросах.""").strip()))

elif bs == "48":
  print(Colorate.Horizontal(Colors.green_to_white, ("""    
Как создавать свои софты? Многие мои подписчики задавали этот вопрос. Итак начнем.



Способ 1 - копипастеры.

1 способ представляет из себя 2 действия : 
1-ое действие : залесть в код
2-ое действие : поменять чужие каналы, и чужой баннер на свои и свой.

Конечно всегда так не получится делать, ведь есть защита от этого. Бесплатный шифровчик кода : https://freecodingtools.org/py-obfuscator
Сделать свой баннер, там есть любые шрифты можно там : https://patorjk.com/software/taag/#p=display&f=Graffiti&t=



Способ 2 - нормальные кодеры.

2 способ это просто напрочь выучить язык программирования python. Или же генерировать всё у нейросети.

мануал сделан к софту "suicide"

""").strip()))

elif bs == "49":
    subprocess.run(['python', 'gencompl.py']) 

elif bs == "50":
    subprocess.run(['python', 'gencit.py']) 

elif bs == "51":
    subprocess.run(['python', 'genstih.py']) 

elif bs == "52":
    subprocess.run(['python', 'game1.py']) 

elif bs == "53":
    subprocess.run(['python', 'game2.py'])

elif bs == "54":
    subprocess.run(['python', 'genlen.py'])

elif bs == "55":
    subprocess.run(['python', 'gennumb.py'])

elif bs == "56":
    subprocess.run(['python', 'gensh.py'])

elif bs == "57":
    subprocess.run(['python', 'genauto.py'])

elif bs == "58":
    subprocess.run(['python', 'genstories.py'])

elif bs == "59":
    subprocess.run(['python', 'genaction.py'])

elif bs == "60":
    subprocess.run(['python', 'tiktok.py'])

elif bs == "61":
    subprocess.run(['python', 'long.py'])

elif bs == "62":
    subprocess.run(['python', 'youtube.py'])

elif bs == "63":
    subprocess.run(['python', 'pinterest.py'])

elif bs == "64":
  print(Colorate.Horizontal(Colors.green_to_white, ("""   
боты для пробива:

по нику

@clerkinfobot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах

@dosie_Bot — как и в боте uabaza дает информацио о паспорте только польностью, 3 бесплатные попытки

 @find_caller_bot — найдет ФИО владельца номера телефона

 @get_caller_bot — поиск по утечкам персональных данных и записным книгам абонентов, может найти ФИО, дату рождения, e-mail

@get_kolesa_bot — найдет объявления на колеса.кз

@get_kontakt_bot — найдет как записан номер в контактах, дает результаты что и getcontact

 @getbank_bot — дает номер карты и полное ФИО клиента банка

@GetFb_bot — бот находит Facebook

@Getphonetestbot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах

@info_baza_bot — поиск в базе данных

@mailsearchbot — найдет часть пароля

 @MyGenisBot — найдет имя и фамилию владельца номера

@phone_avito_bot — найдет аккаунт на Авито

 @SafeCallsBot — бесплатные анонимные звонки на любой номер телефона с подменой Caller ID

@usersbox_bot — бот найдет аккаунты в ВК у которых в поле номера телефона указан искомый номер



Бот для пробива по номеру 



 @phone_avito_bot - пробив по номеру, выдаст Avito

 @HowToFind_bot - бот который может посоветовать различные Telegram каналы спомагательные для деанонимизации
+analog @osint_mindset

 @deanonym_bot — с помощью данного бота можно узнать номер любого пользователя Telegram

@getfb_bot - при помощи номера сможем найти аккаунт в Facebok

@GetYandexBot - пробив по почте выдает различные данные

 @GetPhone_Bot - пробив по номеру выдает различные данные


 @maigret_osint_bot — найдет аккаунты с таким ником, самый точный бот

 @mailsearchbot — найдет часть пароля, поиск по логину

 @StealDetectorBOT — найдет утекшие пароли аккаунта

 @info_baza_bot — покажет из какой базы слита почта, 2 бесплатных скана

@last4mailbot — бот найдет последние 4 цифры номера телефона клиента Сбербанка

 @mailsearchbot — ищет по базе, дает часть пароля

 @StealDetectorBOT — найдет утекшие пароли

 @GetGmail_bot — бот найдет адрес почты Gmail к которой привязан искомый email, 2 бесплатных результата и бесконечное число попыток

@SangMataInfo_bot - покажет историю смены ника и юзернейма по айди тг

@cryptoscanning_bot - покажет слитый номер, айпи по айди

@tgscanrobot - ищет чаты, в которых состоит человек по айди

@creationdatebot - покажет дату создания акка

@telesint_bot - покажет чаты(3 запроса бесплатных)

@TgAnalyst_bot - покажет слитый номер, айпи и геопозицию(не юзать на основном акке)

@CheckID_AIDbot - покажет айди аккаунта

@eyeofbeholder_bot - покажет интересы аккаунта


И так это были все боты которые мне удалось найти перейдем к сайтам


сайты:


Заходим на сайт 220vk.com там вы можете увидеть кого жертва добавляла и удалял таким способом можной найти родственников и одноклассников.

Заходим най сайт http://www.kody.su/check-tel#text Вводим его киви(номер)и узнаем страну/город.


""").strip()))


elif bs == "65":
    subprocess.run(['python', 'genan.py'])

elif bs == "66":
  print(Colorate.Horizontal(Colors.green_to_white, (""" 
  Короче в гб перейти в "мой профиль", потом выбрать "удалить данные",
а потом заполнить данные которые нужно удалить, и подождать 7 дней. В случае отклонения пишите в поддержку.

  В других любых ботах просто пишем в поддержку и предлагаем деньги за удаление наших данных.
""").strip()))

elif bs == "67":
  print(Colorate.Horizontal(Colors.green_to_white, (""" 😎 Снимаем спам-бан в Telegram 

😎 Скорее всего, вы сталкивались с подобной ситуацией, когда на ваш аккаунт вешали спам, и хорошо, если это было всего лишь на 3-7 дней. Некоторым, включая меня, вешали вечный спам, то есть его невозможно снять. Но, проявив немного смекалки, можно придумать массу вариантов, как избавиться от спама. Один из них - я сейчас продемонстрирую!

😎 Инструкция:
1) Заходим в @SpamBot и жмём "/start".
2) Нажимаем на "Это ошибка", далее "Да", потом "Нет, ничего подобного не было".
3) Затем бот попросит Вас описать ситуацию, на что Вы отвечаете следующем сообщением:

😎 Здравствуйте! Прошу вас снять спам бан с моего аккаунта! Дело в том, что я являюсь жителем Украины, тем самым люди из России кидают жалобу, что я считаю неприемлемым!

😎 Данный способ работает отлично, в 100% случаев Вам снимут спам-бан с аккаунта! Также добавлю, что, текст аналогично прекрасно работает если поменять местами в нём "жертву" и "недоброжелателей"! Сохраняйте.

Наш второй канал, где можно скачать многие софты которых нету в этом канале - подпишись пока не заблокировали! (https://t.me/+E_XPkxOGjjpiNTUy)

""").strip()))

elif bs == "78":
  print(Colorate.Horizontal(Colors.red_to_white, ("""    .____ _                                
                / ___|| | ___ __ ___ ___ ___ _ __  
                \___ \| |/ / '_ ` _ \ / _ \ / _ \| '_ \
                 ___) | <| | | | | | (_) | (_) | | | |
                |____/|_|\_\_| |_| |_|\___/ \___/|_| |_|

                           Поддержать автора можно. СКОРО
""").strip()))

elif bs == "79":
  print(Colorate.Horizontal(Colors.red_to_white, ("""    .____ _                                
               / ___|| | ___ __ ___ ___ ___ _ __  
               \___ \| |/ / '_ ` _ \ / _ \ / _ \| '_ \
                 ___) | <| | | | | | (_) | (_) | | | |
                |____/|_|\_\_| |_| |_|\___/ \___/|_| |_|

                                    Автор данного проекта :СКОРО
                                 Текущая доступная версия софта : 2.2
""").strip()))

elif bs == "80":
  print(Colorate.Horizontal(Colors.red_to_white, ("""    .____ _                                
               / ___|| | ___ __ ___ ___ ___ _ __  
               \___ \| |/ / '_ ` _ \ / _ \ / _ \| '_ \
                  ___) | <| | | | | | (_) | (_) | | | |
                |____/|_|\_\_| |_| |_|\___/ \___/|_| |_|

                           Как использовать поиск по номеру : активируйте впн.
                                   Авторы проекта : СКОРО
                                 Канал проекта : СКОРО
                                   Дата релиза : 07.04.2025
""").strip()))





import random
import string

import os

COLOR_CODE = {
    "GREEN": "\033[0;32m",
    "RESET": "\033[0m",
}
os.system("cls")
print(f'''{COLOR_CODE["GREEN"]} 
BY IKEA''')                            

#Кол-во символов в пароле
num_iterations = int(input("Введите количество символов в пароле: "))

random_string = ""
for i in range(num_iterations):
    random_letter = random.choice(string.ascii_letters)
    random_string += random_letter
    
    random_digit = random.randint(0, 9)
    random_string += str(random_digit)
    
    symbols = string.ascii_letters + string.digits + string.punctuation
    random_symbol = random.choice(symbols)
    random_string += random_symbol

print("Сгенерированный пароль:", random_string)

#ВАЖНО!!! Если вы ввели число например 8, то будет 8 знаков, 8 букв и 8 цифр. Посему если вы ввели число "8" то у вас будет 24 символа.